import mysql.connector

def conectar_bd():
    try:
        conexion = mysql.connector.connect(
            host="localhost",        # Cambia "localhost" si tu base está en otro servidor
            user="tu_usuario",       # Cambia "tu_usuario" por el usuario configurado en MySQL
            password="dedirapues13", # Cambia "tu_contraseña" por la contraseña del usuario
            database="SugarRush"     # Nombre de la base de datos que estás utilizando
        )
        return conexion
    except mysql.connector.Error as err:
        print(f"Error de conexión: {err}")
        return None
