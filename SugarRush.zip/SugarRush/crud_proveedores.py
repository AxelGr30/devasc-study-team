import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector

def conectar_bd():
    return mysql.connector.connect(
        host="localhost",
        user="tu_usuario",
        password="tu_contraseña",
        database="SugarRush"
    )

# Función para agregar proveedor
def agregar_proveedor():
    try:
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO proveedores (nombre) VALUES (%s)", (nombre_entry.get(),))
        conexion.commit()
        cursor.close()
        conexion.close()
        actualizar_lista_proveedores()
        messagebox.showinfo("Éxito", "Proveedor agregado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Función para actualizar la lista de proveedores
def actualizar_lista_proveedores():
    for item in lista_proveedores.get_children():
        lista_proveedores.delete(item)
    conexion = conectar_bd()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM proveedores")
    for id, nombre in cursor.fetchall():
        lista_proveedores.insert("", "end", values=(id, nombre))
    cursor.close()
    conexion.close()

# Función para eliminar proveedor
def eliminar_proveedor():
    try:
        selected_item = lista_proveedores.selection()[0]
        proveedor_id = lista_proveedores.item(selected_item)['values'][0]
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM proveedores WHERE id = %s", (proveedor_id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        lista_proveedores.delete(selected_item)
        messagebox.showinfo("Éxito", "Proveedor eliminado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

root_proveedores = tk.Tk()
root_proveedores.title("Gestión de Proveedores")

tk.Label(root_proveedores, text="Nombre del Proveedor:").grid(row=0, column=0, padx=10, pady=10)
nombre_entry = tk.Entry(root_proveedores)
nombre_entry.grid(row=0, column=1, padx=10, pady=10)

tk.Button(root_proveedores, text="Agregar", command=agregar_proveedor).grid(row=0, column=2, padx=10, pady=10)
tk.Button(root_proveedores, text="Eliminar", command=eliminar_proveedor).grid(row=0, column=3, padx=10, pady=10)

lista_proveedores = ttk.Treeview(root_proveedores, columns=("ID", "Nombre"), show="headings")
lista_proveedores.heading("ID", text="ID")
lista_proveedores.heading("Nombre", text="Nombre")
lista_proveedores.grid(row=1, column=0, columnspan=4, padx=10, pady=10)

actualizar_lista_proveedores()

root_proveedores.mainloop()
