import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector

# Función para agregar un cliente
def agregar_cliente():
    try:
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute(
            "INSERT INTO clientes (nombre, telefono, direccion, correo) VALUES (%s, %s, %s, %s)",
            (nombre_entry.get(), telefono_entry.get(), direccion_entry.get(), correo_entry.get())
        )
        conexion.commit()
        cursor.close()
        conexion.close()
        actualizar_lista_clientes()
        messagebox.showinfo("Éxito", "Cliente agregado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Función para actualizar la lista de clientes
def actualizar_lista_clientes():
    for item in lista_clientes.get_children():
        lista_clientes.delete(item)
    conexion = conectar_bd()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM clientes")
    for id, nombre, telefono, direccion, correo in cursor.fetchall():
        lista_clientes.insert("", "end", values=(id, nombre, telefono, direccion, correo))
    cursor.close()
    conexion.close()

# Función para eliminar un cliente
def eliminar_cliente():
    try:
        selected_item = lista_clientes.selection()[0]
        cliente_id = lista_clientes.item(selected_item)['values'][0]
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM clientes WHERE id = %s", (cliente_id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        lista_clientes.delete(selected_item)
        messagebox.showinfo("Éxito", "Cliente eliminado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))


root_clientes = tk.Tk()
root_clientes.title("Gestión de Clientes")

tk.Label(root_clientes, text="Nombre:").grid(row=0, column=0, padx=10, pady=5)
nombre_entry = tk.Entry(root_clientes)
nombre_entry.grid(row=0, column=1, padx=10, pady=5)

tk.Label(root_clientes, text="Teléfono:").grid(row=1, column=0, padx=10, pady=5)
telefono_entry = tk.Entry(root_clientes)
telefono_entry.grid(row=1, column=1, padx=10, pady=5)

tk.Label(root_clientes, text="Dirección:").grid(row=2, column=0, padx=10, pady=5)
direccion_entry = tk.Entry(root_clientes)
direccion_entry.grid(row=2, column=1, padx=10, pady=5)

tk.Label(root_clientes, text="Correo:").grid(row=3, column=0, padx=10, pady=5)
correo_entry = tk.Entry(root_clientes)
correo_entry.grid(row=3, column=1, padx=10, pady=5)

tk.Button(root_clientes, text="Agregar", command=agregar_cliente).grid(row=4, column=0, padx=10, pady=10)
tk.Button(root_clientes, text="Eliminar", command=eliminar_cliente).grid(row=4, column=1, padx=10, pady=10)

lista_clientes = ttk.Treeview(root_clientes, columns=("ID", "Nombre", "Teléfono", "Dirección", "Correo"), show="headings")
lista_clientes.heading("ID", text="ID")
lista_clientes.heading("Nombre", text="Nombre")
lista_clientes.heading("Teléfono", text="Teléfono")
lista_clientes.heading("Dirección", text="Dirección")
lista_clientes.heading("Correo", text="Correo")
lista_clientes.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

actualizar_lista_clientes()

root_clientes.mainloop()
