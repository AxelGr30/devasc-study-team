import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector

# Función para agregar un elemento al menú
def agregar_menu():
    try:
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute(
            "INSERT INTO menu (nombre, descripcion, precio, categoria) VALUES (%s, %s, %s, %s)",
            (nombre_entry.get(), descripcion_entry.get(), precio_entry.get(), categoria_entry.get())
        )
        conexion.commit()
        cursor.close()
        conexion.close()
        actualizar_lista_menu()
        messagebox.showinfo("Éxito", "Elemento del menú agregado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Función para actualizar la lista del menú
def actualizar_lista_menu():
    for item in lista_menu.get_children():
        lista_menu.delete(item)
    conexion = conectar_bd()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM menu")
    for id, nombre, descripcion, precio, categoria in cursor.fetchall():
        lista_menu.insert("", "end", values=(id, nombre, descripcion, precio, categoria))
    cursor.close()
    conexion.close()

# Función para eliminar un elemento del menú
def eliminar_menu():
    try:
        selected_item = lista_menu.selection()[0]
        menu_id = lista_menu.item(selected_item)['values'][0]
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM menu WHERE id = %s", (menu_id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        lista_menu.delete(selected_item)
        messagebox.showinfo("Éxito", "Elemento del menú eliminado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

root_menu = tk.Tk()
root_menu.title("Gestión de Menú")

tk.Label(root_menu, text="Nombre:").grid(row=0, column=0, padx=10, pady=5)
nombre_entry = tk.Entry(root_menu)
nombre_entry.grid(row=0, column=1, padx=10, pady=5)

tk.Label(root_menu, text="Descripción:").grid(row=1, column=0, padx=10, pady=5)
descripcion_entry = tk.Entry(root_menu)
descripcion_entry.grid(row=1, column=1, padx=10, pady=5)

tk.Label(root_menu, text="Precio:").grid(row=2, column=0, padx=10, pady=5)
precio_entry = tk.Entry(root_menu)
precio_entry.grid(row=2, column=1, padx=10, pady=5)

tk.Label(root_menu, text="Categoría:").grid(row=3, column=0, padx=10, pady=5)
categoria_entry = tk.Entry(root_menu)
categoria_entry.grid(row=3, column=1, padx=10, pady=5)

tk.Button(root_menu, text="Agregar", command=agregar_menu).grid(row=4, column=0, padx=10, pady=10)
tk.Button(root_menu, text="Eliminar", command=eliminar_menu).grid(row=4, column=1, padx=10, pady=10)

lista_menu = ttk.Treeview(root_menu, columns=("ID", "Nombre", "Descripción", "Precio", "Categoría"), show="headings")
lista_menu.heading("ID", text="ID")
lista_menu.heading("Nombre", text="Nombre")
lista_menu.heading("Descripción", text="Descripción")
lista_menu.heading("Precio", text="Precio")
lista_menu.heading("Categoría", text="Categoría")
lista_menu.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

actualizar_lista_menu()

root_menu.mainloop()
