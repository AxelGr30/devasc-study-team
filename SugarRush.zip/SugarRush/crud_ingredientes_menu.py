import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector

# Función para agregar un ingrediente al menú
def agregar_ingrediente():
    try:
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute(
            "INSERT INTO ingredientes_menu (id_menu, id_producto, cantidad) VALUES (%s, %s, %s)",
            (menu_entry.get(), producto_entry.get(), cantidad_entry.get())
        )
        conexion.commit()
        cursor.close()
        conexion.close()
        actualizar_lista_ingredientes()
        messagebox.showinfo("Éxito", "Ingrediente agregado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Función para actualizar la lista de ingredientes
def actualizar_lista_ingredientes():
    for item in lista_ingredientes.get_children():
        lista_ingredientes.delete(item)
    conexion = conectar_bd()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM ingredientes_menu")
    for id, id_menu, id_producto, cantidad in cursor.fetchall():
        lista_ingredientes.insert("", "end", values=(id, id_menu, id_producto, cantidad))
    cursor.close()
    conexion.close()

# Función para eliminar un ingrediente del menú
def eliminar_ingrediente():
    try:
        selected_item = lista_ingredientes.selection()[0]
        ingrediente_id = lista_ingredientes.item(selected_item)['values'][0]
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM ingredientes_menu WHERE id = %s", (ingrediente_id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        lista_ingredientes.delete(selected_item)
        messagebox.showinfo("Éxito", "Ingrediente eliminado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

root_ingredientes = tk.Tk()
root_ingredientes.title("Gestión de Ingredientes del Menú")

tk.Label(root_ingredientes, text="ID del Menú:").grid(row=0, column=0, padx=10, pady=5)
menu_entry = tk.Entry(root_ingredientes)
menu_entry.grid(row=0, column=1, padx=10, pady=5)

tk.Label(root_ingredientes, text="ID del Producto:").grid(row=1, column=0, padx=10, pady=5)
producto_entry = tk.Entry(root_ingredientes)
producto_entry.grid(row=1, column=1, padx=10, pady=5)

tk.Label(root_ingredientes, text="Cantidad:").grid(row=2, column=0, padx=10, pady=5)
cantidad_entry = tk.Entry(root_ingredientes)
cantidad_entry.grid(row=2, column=1, padx=10, pady=5)

tk.Button(root_ingredientes, text="Agregar", command=agregar_ingrediente).grid(row=3, column=0, padx=10, pady=10)
tk.Button(root_ingredientes, text="Eliminar", command=eliminar_ingrediente).grid(row=3, column=1, padx=10, pady=10)

lista_ingredientes = ttk.Treeview(root_ingredientes, columns=("ID", "ID Menú", "ID Producto", "Cantidad"), show="headings")
lista_ingredientes.heading("ID", text="ID")
lista_ingredientes.heading("ID Menú", text="ID Menú")
lista_ingredientes.heading("ID Producto", text="ID Producto")
lista_ingredientes.heading("Cantidad", text="Cantidad")
lista_ingredientes.grid(row=4, column=0, columnspan=2, padx=10, pady=10)

actualizar_lista_ingredientes()

root_ingredientes.mainloop()
