import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector

# Función para agregar un producto
def agregar_producto():
    try:
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute(
            "INSERT INTO productos (nombre, marca, precio, id_proveedor) VALUES (%s, %s, %s, %s)",
            (nombre_entry.get(), marca_entry.get(), precio_entry.get(), proveedor_entry.get())
        )
        conexion.commit()
        cursor.close()
        conexion.close()
        actualizar_lista_productos()
        messagebox.showinfo("Éxito", "Producto agregado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Función para actualizar la lista de productos
def actualizar_lista_productos():
    for item in lista_productos.get_children():
        lista_productos.delete(item)
    conexion = conectar_bd()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM productos")
    for id, nombre, marca, precio, id_proveedor in cursor.fetchall():
        lista_productos.insert("", "end", values=(id, nombre, marca, precio, id_proveedor))
    cursor.close()
    conexion.close()

# Función para eliminar un producto
def eliminar_producto():
    try:
        selected_item = lista_productos.selection()[0]
        producto_id = lista_productos.item(selected_item)['values'][0]
        conexion = conectar_bd()
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM productos WHERE id = %s", (producto_id,))
        conexion.commit()
        cursor.close()
        conexion.close()
        lista_productos.delete(selected_item)
        messagebox.showinfo("Éxito", "Producto eliminado correctamente.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

root_productos = tk.Tk()
root_productos.title("Gestión de Productos")

tk.Label(root_productos, text="Nombre del Producto:").grid(row=0, column=0, padx=10, pady=5)
nombre_entry = tk.Entry(root_productos)
nombre_entry.grid(row=0, column=1, padx=10, pady=5)

tk.Label(root_productos, text="Marca:").grid(row=1, column=0, padx=10, pady=5)
marca_entry = tk.Entry(root_productos)
marca_entry.grid(row=1, column=1, padx=10, pady=5)

tk.Label(root_productos, text="Precio:").grid(row=2, column=0, padx=10, pady=5)
precio_entry = tk.Entry(root_productos)
precio_entry.grid(row=2, column=1, padx=10, pady=5)

tk.Label(root_productos, text="ID del Proveedor:").grid(row=3, column=0, padx=10, pady=5)
proveedor_entry = tk.Entry(root_productos)
proveedor_entry.grid(row=3, column=1, padx=10, pady=5)

tk.Button(root_productos, text="Agregar", command=agregar_producto).grid(row=4, column=0, padx=10, pady=10)
tk.Button(root_productos, text="Eliminar", command=eliminar_producto).grid(row=4, column=1, padx=10, pady=10)

lista_productos = ttk.Treeview(root_productos, columns=("ID", "Nombre", "Marca", "Precio", "ID Proveedor"), show="headings")
lista_productos.heading("ID", text="ID")
lista_productos.heading("Nombre", text="Nombre")
lista_productos.heading("Marca", text="Marca")
lista_productos.heading("Precio", text="Precio")
lista_productos.heading("ID Proveedor", text="ID Proveedor")
lista_productos.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

actualizar_lista_productos()

root_productos.mainloop()
